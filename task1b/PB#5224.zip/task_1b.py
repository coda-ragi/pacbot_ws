'''
# Team ID:          <5224>
# Theme:            PacBot
# Author List:      <Anurag Singh, Ashutosh Vishwakarma, Saket Kr. Rai, Rana Pratap Singh>
# Filename:         task_1b_boilerplate.py
# Functions:        _mqtt_client, clamp, send_velocity, stop_robot,
#                   reset_pid, reset_turn, get_sensor_values,
#                   get_front_distance, front_is_blocked, left_is_open,
#                   right_is_open, follow_corridor, start_left_turn,
#                   start_right_turn, start_u_turn, choose_direction,
#                   perform_turn, perform_post_turn, on_message,
#                   on_connect, main
# Global variables: MQTT_HOST, MQTT_PORT, TOPIC_SENSORS,
#                   TOPIC_WHEEL_VEL, BASE_SPEED, TURN_SPEED, MAX_SPEED,
#                   TARGET_SIDE_DISTANCE, FRONT_BLOCKED_DISTANCE,
#                   SIDE_OPEN_DISTANCE, KP, KI, KD, INTEGRAL_LIMIT,
#                   integral, previous_error, TURN_ANGLE_90,
#                   TURN_ANGLE_180, MAX_TURN_TIME_90,
#                   MAX_TURN_TIME_180, turn_angle, turn_timer,
#                   ENTRY_TIME, entry_timer, POST_TURN_TIME,
#                   post_turn_timer, STATE_ENTRY, STATE_FOLLOW,
#                   STATE_TURN_LEFT, STATE_TURN_RIGHT, STATE_TURN_BACK,
#                   STATE_POST_TURN, state
'''

import json
import math

import paho.mqtt.client as mqtt


# MQTT connection parameters.
MQTT_HOST = "localhost"
MQTT_PORT = 1883

# MQTT topics used for sensor input and wheel velocity output.
TOPIC_SENSORS = "pacbot/sensors"
TOPIC_WHEEL_VEL = "pacbot/wheel_vel"


# Main forward movement speed.
BASE_SPEED = 7.5

# Wheel speed used during in-place turns.
TURN_SPEED = 6.0

# Maximum allowed wheel velocity command.
MAX_SPEED = 10.0


# Desired distance from the side walls.
TARGET_SIDE_DISTANCE = 0.20

# Forward distance below which an obstacle is considered blocked.
FRONT_BLOCKED_DISTANCE = 0.12

# Minimum side distance required to consider a side open.
SIDE_OPEN_DISTANCE = 0.30


# PID proportional gain.
KP = 22.5

# PID integral gain.
KI = 0.375

# PID derivative gain.
KD = 1.50

# Maximum allowed accumulated PID integral error.
INTEGRAL_LIMIT = 1.0

# Accumulated PID integral error.
integral = 0.0

# Previous PID error used for calculating the derivative term.
previous_error = 0.0


# Target angle for a normal maze turn.
TURN_ANGLE_90 = math.radians(90.0)

# Target angle for a dead-end U-turn.
TURN_ANGLE_180 = math.radians(180.0)

# Maximum time allowed for a normal 90-degree turn.
MAX_TURN_TIME_90 = 1.0

# Maximum time allowed for a 180-degree U-turn.
MAX_TURN_TIME_180 = 1.8

# Accumulated angular displacement during the current turn.
turn_angle = 0.0

# Elapsed time during the current turn.
turn_timer = 0.0


# Time spent moving through the starting region.
ENTRY_TIME = 0.25

# Elapsed time since entering the maze.
entry_timer = 0.0


# Time spent moving forward after completing a turn.
POST_TURN_TIME = 0.10

# Elapsed time since the current turn was completed.
post_turn_timer = 0.0


# Controller states.
STATE_ENTRY = 0
STATE_FOLLOW = 1
STATE_TURN_LEFT = 2
STATE_TURN_RIGHT = 3
STATE_TURN_BACK = 4
STATE_POST_TURN = 5

# Current controller state.
state = STATE_ENTRY


def _mqtt_client():
    '''
    Purpose:
    ---
    Creates and returns an MQTT client object compatible with the
    installed version of the paho-mqtt library.

    Input Arguments:
    ---
    None

    Returns:
    ---
    `client` : [ mqtt.Client ]
      Configured MQTT client object.

    Example call:
    ---
    client = _mqtt_client()
    '''

    try:
        return mqtt.Client(
            mqtt.CallbackAPIVersion.VERSION2
        )

    except AttributeError:
        return mqtt.Client()


def clamp(value, minimum, maximum):
    '''
    Purpose:
    ---
    Restricts a numerical value to the specified minimum and maximum
    limits.

    Input Arguments:
    ---
    `value` : [ float ]
      Value that needs to be restricted.

    `minimum` : [ float ]
      Lower limit for the value.

    `maximum` : [ float ]
      Upper limit for the value.

    Returns:
    ---
    `clamped_value` : [ float ]
      Value restricted to the specified range.

    Example call:
    ---
    limited_speed = clamp(12.0, -10.0, 10.0)
    '''

    return max(
        minimum,
        min(maximum, value)
    )


def send_velocity(client, left, right):
    '''
    Purpose:
    ---
    Sends the desired left and right wheel velocities to PacBot
    through the MQTT wheel velocity topic.

    Input Arguments:
    ---
    `client` : [ mqtt.Client ]
      MQTT client used to publish the velocity command.

    `left` : [ float ]
      Desired velocity of the left wheel.

    `right` : [ float ]
      Desired velocity of the right wheel.

    Returns:
    ---
    None

    Example call:
    ---
    send_velocity(client, 1.0, 1.0)
    '''

    left = clamp(
        left,
        -MAX_SPEED,
        MAX_SPEED
    )

    right = clamp(
        right,
        -MAX_SPEED,
        MAX_SPEED
    )

    client.publish(
        TOPIC_WHEEL_VEL,
        json.dumps({
            "left": float(left),
            "right": float(right)
        })
    )


def stop_robot(client):
    '''
    Purpose:
    ---
    Stops PacBot by sending zero velocity commands to both wheels.

    Input Arguments:
    ---
    `client` : [ mqtt.Client ]
      MQTT client used to publish the stop command.

    Returns:
    ---
    None

    Example call:
    ---
    stop_robot(client)
    '''

    send_velocity(
        client,
        0.0,
        0.0
    )


def reset_pid():
    '''
    Purpose:
    ---
    Clears the accumulated PID integral and previous error values.
    This prevents PID history from one corridor affecting movement
    after a turn.

    Input Arguments:
    ---
    None

    Returns:
    ---
    None

    Example call:
    ---
    reset_pid()
    '''

    global integral
    global previous_error

    integral = 0.0
    previous_error = 0.0


def reset_turn():
    '''
    Purpose:
    ---
    Resets the accumulated turn angle and turn timer before starting
    a new turn.

    Input Arguments:
    ---
    None

    Returns:
    ---
    None

    Example call:
    ---
    reset_turn()
    '''

    global turn_angle
    global turn_timer

    turn_angle = 0.0
    turn_timer = 0.0


def get_sensor_values(data):
    '''
    Purpose:
    ---
    Extracts the ToF sensor readings, gyroscope yaw rate, and
    simulation timestep from the received MQTT sensor data.

    Input Arguments:
    ---
    `data` : [ dict ]
      Dictionary containing the sensor values received from PacBot.

    Returns:
    ---
    `fl` : [ float ]
      Distance measured by the front-left side-facing sensor.

    `fr` : [ float ]
      Distance measured by the front-right side-facing sensor.

    `sl` : [ float ]
      Distance measured by the forward-facing left sensor.

    `sr` : [ float ]
      Distance measured by the forward-facing right sensor.

    `yaw_rate` : [ float ]
      Angular velocity about the z-axis in rad/s.

    `dt` : [ float ]
      Simulation timestep in seconds.

    Example call:
    ---
    fl, fr, sl, sr, yaw_rate, dt = get_sensor_values(data)
    '''

    fl = float(data["fl"])
    fr = float(data["fr"])

    sl = float(data["sl"])
    sr = float(data["sr"])

    yaw_rate = float(
        data["gyro"][2]
    )

    dt = float(
        data["dt"]
    )

    return (
        fl,
        fr,
        sl,
        sr,
        yaw_rate,
        dt
    )


def get_front_distance(sl, sr):
    '''
    Purpose:
    ---
    Calculates the average forward distance using the two
    forward-facing ToF sensors.

    Input Arguments:
    ---
    `sl` : [ float ]
      Distance measured by the forward-left sensor.

    `sr` : [ float ]
      Distance measured by the forward-right sensor.

    Returns:
    ---
    `front_distance` : [ float ]
      Average distance to the obstacle ahead.

    Example call:
    ---
    front_distance = get_front_distance(sl, sr)
    '''

    return (
        sl + sr
    ) / 2.0


def front_is_blocked(sl, sr):
    '''
    Purpose:
    ---
    Determines whether an obstacle is close enough in front of
    PacBot to require a navigation decision.

    Input Arguments:
    ---
    `sl` : [ float ]
      Distance measured by the forward-left sensor.

    `sr` : [ float ]
      Distance measured by the forward-right sensor.

    Returns:
    ---
    `is_blocked` : [ bool ]
      True if the average forward distance is below the blocking
      threshold, otherwise False.

    Example call:
    ---
    if front_is_blocked(sl, sr):
        print("Obstacle ahead")
    '''

    front_distance = get_front_distance(
        sl,
        sr
    )

    return (
        front_distance
        < FRONT_BLOCKED_DISTANCE
    )


def left_is_open(fl):
    '''
    Purpose:
    ---
    Determines whether the left side of the robot has sufficient
    open space for a turn.

    Input Arguments:
    ---
    `fl` : [ float ]
      Distance measured by the left-facing ToF sensor.

    Returns:
    ---
    `is_open` : [ bool ]
      True if the left side is open, otherwise False.

    Example call:
    ---
    if left_is_open(fl):
        print("Left side is open")
    '''

    return (
        fl > SIDE_OPEN_DISTANCE
    )


def right_is_open(fr):
    '''
    Purpose:
    ---
    Determines whether the right side of the robot has sufficient
    open space for a turn.

    Input Arguments:
    ---
    `fr` : [ float ]
      Distance measured by the right-facing ToF sensor.

    Returns:
    ---
    `is_open` : [ bool ]
      True if the right side is open, otherwise False.

    Example call:
    ---
    if right_is_open(fr):
        print("Right side is open")
    '''

    return (
        fr > SIDE_OPEN_DISTANCE
    )


def follow_corridor(client, fl, fr, dt):
    '''
    Purpose:
    ---
    Keeps PacBot approximately centered between the side walls
    using PID control based on the difference between the left
    and right side distances.

    Input Arguments:
    ---
    `client` : [ mqtt.Client ]
      MQTT client used to publish wheel velocities.

    `fl` : [ float ]
      Distance measured by the left-facing ToF sensor.

    `fr` : [ float ]
      Distance measured by the right-facing ToF sensor.

    `dt` : [ float ]
      Simulation timestep in seconds.

    Returns:
    ---
    None

    Example call:
    ---
    follow_corridor(client, fl, fr, dt)
    '''

    global integral
    global previous_error

    # A positive error means the robot is closer to the left wall.
    error = fr - fl

    # Accumulate the error over time for the integral term.
    integral += (
        error * dt
    )

    integral = clamp(
        integral,
        -INTEGRAL_LIMIT,
        INTEGRAL_LIMIT
    )

    if dt > 0.0:
        derivative = (
            error - previous_error
        ) / dt

    else:
        derivative = 0.0

    correction = (
        KP * error
        +
        KI * integral
        +
        KD * derivative
    )

    previous_error = error

    left_velocity = (
        BASE_SPEED
        + correction
    )

    right_velocity = (
        BASE_SPEED
        - correction
    )

    left_velocity = clamp(
        left_velocity,
        -MAX_SPEED,
        MAX_SPEED
    )

    right_velocity = clamp(
        right_velocity,
        -MAX_SPEED,
        MAX_SPEED
    )

    send_velocity(
        client,
        left_velocity,
        right_velocity
    )


def start_left_turn():
    '''
    Purpose:
    ---
    Initializes a left turn by resetting PID and turn state and
    changing the controller state to STATE_TURN_LEFT.

    Input Arguments:
    ---
    None

    Returns:
    ---
    None

    Example call:
    ---
    start_left_turn()
    '''

    global state

    reset_pid()
    reset_turn()

    state = STATE_TURN_LEFT


def start_right_turn():
    '''
    Purpose:
    ---
    Initializes a right turn by resetting PID and turn state and
    changing the controller state to STATE_TURN_RIGHT.

    Input Arguments:
    ---
    None

    Returns:
    ---
    None

    Example call:
    ---
    start_right_turn()
    '''

    global state

    reset_pid()
    reset_turn()

    state = STATE_TURN_RIGHT


def start_u_turn():
    '''
    Purpose:
    ---
    Initializes a U-turn by resetting PID and turn state and
    changing the controller state to STATE_TURN_BACK.

    Input Arguments:
    ---
    None

    Returns:
    ---
    None

    Example call:
    ---
    start_u_turn()
    '''

    global state

    reset_pid()
    reset_turn()

    state = STATE_TURN_BACK


def choose_direction(client, fl, fr, sl, sr):
    '''
    Purpose:
    ---
    Selects the navigation direction when an obstacle is detected.
    The current navigation priority is left, followed by right,
    followed by a U-turn when neither side is open.

    Input Arguments:
    ---
    `client` : [ mqtt.Client ]
      MQTT client used for movement commands.

    `fl` : [ float ]
      Distance measured by the left-facing ToF sensor.

    `fr` : [ float ]
      Distance measured by the right-facing ToF sensor.

    `sl` : [ float ]
      Distance measured by the forward-left ToF sensor.

    `sr` : [ float ]
      Distance measured by the forward-right ToF sensor.

    Returns:
    ---
    None

    Example call:
    ---
    choose_direction(client, fl, fr, sl, sr)
    '''

    left_open = left_is_open(fl)
    right_open = right_is_open(fr)

    # Give priority to a left turn when the left side is open.
    if left_open:
        start_left_turn()
        return

    # If the left side is blocked, check the right side.
    if right_open:
        start_right_turn()
        return

    # Neither side is open, so treat the situation as a dead end.
    start_u_turn()


def perform_turn(client, yaw_rate, dt):
    '''
    Purpose:
    ---
    Rotates PacBot using the gyro yaw rate and determines when the
    required 90-degree or 180-degree turn has been completed.

    Input Arguments:
    ---
    `client` : [ mqtt.Client ]
      MQTT client used to publish wheel velocities.

    `yaw_rate` : [ float ]
      Angular velocity about the z-axis in rad/s.

    `dt` : [ float ]
      Simulation timestep in seconds.

    Returns:
    ---
    None

    Example call:
    ---
    perform_turn(client, yaw_rate, dt)
    '''

    global state
    global turn_angle
    global turn_timer
    global post_turn_timer

    turn_timer += dt

    # Integrate angular velocity to estimate the angle turned.
    turn_angle += (
        abs(yaw_rate) * dt
    )

    if state == STATE_TURN_BACK:
        target_angle = TURN_ANGLE_180
        timeout = MAX_TURN_TIME_180

    else:
        target_angle = TURN_ANGLE_90
        timeout = MAX_TURN_TIME_90

    # Apply opposite wheel velocities to rotate the robot.
    if state == STATE_TURN_LEFT:
        send_velocity(
            client,
            -TURN_SPEED,
            TURN_SPEED
        )

    elif state == STATE_TURN_RIGHT:
        send_velocity(
            client,
            TURN_SPEED,
            -TURN_SPEED
        )

    elif state == STATE_TURN_BACK:
        send_velocity(
            client,
            -TURN_SPEED,
            TURN_SPEED
        )

    # Move to the post-turn state after reaching the target angle.
    if turn_angle >= target_angle:
        reset_turn()

        post_turn_timer = 0.0

        state = STATE_POST_TURN

        return

    # Prevent the robot from rotating indefinitely if the gyro
    # does not provide enough angular displacement.
    if turn_timer >= timeout:
        print(
            "WARNING: turn timeout"
        )

        reset_turn()

        post_turn_timer = 0.0

        state = STATE_POST_TURN


def perform_post_turn(client, dt):
    '''
    Purpose:
    ---
    Moves PacBot forward for a short period after a turn so that
    it leaves the corner before returning to normal corridor
    following.

    Input Arguments:
    ---
    `client` : [ mqtt.Client ]
      MQTT client used to publish wheel velocities.

    `dt` : [ float ]
      Simulation timestep in seconds.

    Returns:
    ---
    None

    Example call:
    ---
    perform_post_turn(client, dt)
    '''

    global state
    global post_turn_timer

    post_turn_timer += dt

    send_velocity(
        client,
        BASE_SPEED,
        BASE_SPEED
    )

    if (
        post_turn_timer
        >= POST_TURN_TIME
    ):
        post_turn_timer = 0.0

        reset_pid()

        state = STATE_FOLLOW


def on_message(client, userdata, msg):
    '''
    Purpose:
    ---
    Processes incoming PacBot sensor data and executes the
    appropriate controller state.

    Input Arguments:
    ---
    `client` : [ mqtt.Client ]
      MQTT client receiving the sensor message.

    `userdata` : [ object ]
      User data associated with the MQTT client.

    `msg` : [ mqtt.MQTTMessage ]
      MQTT message containing PacBot sensor data.

    Returns:
    ---
    None

    Example call:
    ---
    Registered automatically as the MQTT message callback.
    '''

    global state
    global entry_timer

    try:
        data = json.loads(
            msg.payload.decode()
        )

        (
            fl,
            fr,
            sl,
            sr,
            yaw_rate,
            dt
        ) = get_sensor_values(data)

        # Move straight through the starting region first.
        if state == STATE_ENTRY:

            entry_timer += dt

            send_velocity(
                client,
                BASE_SPEED,
                BASE_SPEED
            )

            if (
                entry_timer
                >= ENTRY_TIME
            ):
                entry_timer = 0.0

                reset_pid()

                state = STATE_FOLLOW

            return

        # Follow the corridor until a forward obstacle is detected.
        if state == STATE_FOLLOW:

            if front_is_blocked(sl, sr):
                reset_pid()

                choose_direction(
                    client,
                    fl,
                    fr,
                    sl,
                    sr
                )

                return

            follow_corridor(
                client,
                fl,
                fr,
                dt
            )

            return

        # Execute the currently selected turn.
        if state in (
            STATE_TURN_LEFT,
            STATE_TURN_RIGHT,
            STATE_TURN_BACK
        ):
            perform_turn(
                client,
                yaw_rate,
                dt
            )

            return

        # Move forward briefly after completing a turn.
        if state == STATE_POST_TURN:
            perform_post_turn(
                client,
                dt
            )

            return

    except Exception as error:
        print(
            f"Sensor callback error: {error}"
        )

        stop_robot(client)


def on_connect(
    client,
    userdata,
    flags,
    reason_code,
    properties=None
):
    '''
    Purpose:
    ---
    Subscribes the MQTT client to the PacBot sensor topic after
    successfully connecting to the MQTT broker.

    Input Arguments:
    ---
    `client` : [ mqtt.Client ]
      Connected MQTT client.

    `userdata` : [ object ]
      User data associated with the MQTT client.

    `flags` : [ dict ]
      MQTT connection flags.

    `reason_code` : [ int ]
      MQTT connection result code.

    `properties` : [ object ]
      MQTT connection properties for MQTT protocol version 5.

    Returns:
    ---
    None

    Example call:
    ---
    Registered automatically as the MQTT connection callback.
    '''

    print(
        "Connected to MQTT broker."
    )

    client.subscribe(
        TOPIC_SENSORS
    )

    print(
        f"Subscribed to {TOPIC_SENSORS}"
    )


def main():
    '''
    Purpose:
    ---
    Creates the MQTT client, registers the MQTT callbacks,
    connects to the broker, and starts the PacBot control loop.

    Input Arguments:
    ---
    None

    Returns:
    ---
    None

    Example call:
    ---
    main()
    '''

    client = _mqtt_client()

    client.on_connect = on_connect
    client.on_message = on_message

    print(
        f"Connecting to MQTT broker "
        f"{MQTT_HOST}:{MQTT_PORT}..."
    )

    client.connect(
        MQTT_HOST,
        MQTT_PORT,
        60
    )

    print(
        "========================================"
    )

    print(
        "PacBot controller started"
    )

    print(
        f"Base speed : {BASE_SPEED}"
    )

    print(
        f"Turn speed : {TURN_SPEED}"
    )

    print(
        f"Max speed  : {MAX_SPEED}"
    )

    print(
        "========================================"
    )

    try:
        client.loop_forever()

    except KeyboardInterrupt:
        print(
            "\nStopping PacBot..."
        )

        stop_robot(client)

        client.disconnect()


if __name__ == "__main__":
    main()